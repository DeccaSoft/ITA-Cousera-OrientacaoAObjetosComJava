/*
 * author Andr� Morais de Azevedo
 * @date 22/08/2020 20:25
 */
public interface FormatadorNome {
	
	String formatarNome(String nome, String sobrenome);
	
}
