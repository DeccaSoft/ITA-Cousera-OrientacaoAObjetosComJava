/*
 * @Author: Andr� Morais de Azevedo
 * @DateTime: 30/08/2020 16:40
 */
package mecanicas;

import principal.BancoDePalavras;

public class NivelFacil implements MecanicaDoJogo{

	private BancoDePalavras palavras = new BancoDePalavras();
	private static int quantidadeDePalavras = 0;
    private String palavraAtual = palavras.getNext();
    private int palavrasRestantes = palavras.getTamanho();
    private int pontos = 0;
    
    
    @Override
    public String getNivel() {
        return "F�cil";
    }

    @Override
    public String getRegras() {
        return "No Dicion�rio temos 20 Palavaras sobre o tema Java e Orieta��o a Objetos \n"
        		+ "que ser�o embaralhadas de duas maneiras aleat�rias, \n"
        		+ "uma � invertendo-se as letras e a outra � as trocando de posi��o. \n"
        		+ "Neste n�vel, voc� ter� limite de 20 tentativas \n"
        		+ "e a cada palavra acertada, voc� ganhara 2 de pontos \n"
        		+ "no entanto, a cada palavra errada, voc� perder� 1 ponto. \n"
        		+ "ATEN��O: N�o utilize acentos, nem '�' e nem caracteres especias como '-' \n"
        		+ "Boa Sorte!!! \n";
    }

    @Override
    public String getPalavra() {
        return palavraAtual;
    }
    
    @Override
    public String tentativa(String palavra, String resposta) {
        if(palavra.equals(resposta)){
            pontos += 2;
            quantidadeDePalavras++;
            palavraAtual = palavras.getNext();
            return "Parab�ns, Voc� acertou e Ganhou 2 Pontos!!! Ainda falta(m) " + (palavrasRestantes -quantidadeDePalavras) + " Tentativa(s).";
        }else{
            pontos -= 1;
            quantidadeDePalavras++;
            return "Aaahhh... Voc� Errou e Perdeu 1 Ponto!!! Mas N�O Desanime. Tente Novamente, pois ainda falta(m) " + (palavrasRestantes - quantidadeDePalavras) + " Tentativa(s).";
        }
    }

    @Override
    public String getResultadoFinal() {
        
        if(pontos <= 0) {
        	return "Infelizmente, n�o foi dessa vez... Sua pontua��o foi: " + pontos + " Pontos!!!";
        }else {
        	return "Parab�ns!!! Sua pontua��o foi: " + pontos + " Ponto(s)!";
        }
    }
    
    @Override
    public boolean isOver() {
    	if(quantidadeDePalavras == palavras.getTamanho()) {
    		return true;
    	}else {
    		return false;
    	}
    }
}
