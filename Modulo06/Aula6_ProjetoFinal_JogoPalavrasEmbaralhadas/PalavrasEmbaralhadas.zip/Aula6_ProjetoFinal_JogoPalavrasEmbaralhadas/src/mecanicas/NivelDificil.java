/*
 * @Author: Andr� Morais de Azevedo
 * @DateTime: 30/08/2020 16:44
 */
package mecanicas;

import principal.BancoDePalavras;

public class NivelDificil implements MecanicaDoJogo{

    private BancoDePalavras palavras = new BancoDePalavras();
    private int qtdAcertos = 0;
	private boolean isErrou = false;
    
    @Override
    public String getNivel() {
        return "Dif�cil";
    }

    @Override
    public String getRegras() {
    	return "No Dicion�rio temos 20 Palavaras sobre o tema Java e Orieta��o a Objetos \n"
        		+ "que ser�o embaralhadas de duas maneiras aleat�rias, \n"
        		+ "tente descobrir quais s�o elas... Isso pode ser crucial para voc� vencer. \n"
        		+ "Neste n�vel, voc� n�o ter� limite de tentativas \n"
        		+ "e a cada palavra acertada, voc� poder� tentar adivinhar a pr�xima \n"
        		+ "no entanto, se errar UMA palavra, voc� perder� o Jogo. \n"
        		+ "ATEN��O: N�o utilize acentos, nem '�' e nem caracteres especias como '-' \n"
        		+ "Aqui � Tudo ou Nada!!! Boa Sorte!!! \n";
    }

    @Override
    public String getPalavra() {
        return palavras.getNext();
    }

    @Override
    public String tentativa(String palavra, String resposta) {
        if(palavra.equals(resposta)){
            qtdAcertos++;
            return "Parab�ns, Voc� acertou esta Palavra!!! Tente a Pr�xima...";
        }else{
            isErrou = true;
            return "Aaahhh... Voc� Errou!!! Mas N�O Desanime... Tente Novamente!!!";
        }
    }

    @Override
    public String getResultadoFinal() {
    	if (qtdAcertos == 0) {
    		return "Infelizmente, n�o foi dessa vez... Voc� n�o Acertou NENHUMA palavra!!!";
    	}else {
            return "Parab�ns... Voc� Acertou " + qtdAcertos + " das 20 Palavrasdo Dicion�rio.";
    	}

    }
    
    @Override
    public boolean isOver() {
        return isErrou;
    }

}
