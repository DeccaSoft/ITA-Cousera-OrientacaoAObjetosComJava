/*
 * @Author: Andr� Morais de Azevedo
 * @DateTime: 30/08/2020 16:42
 */
package mecanicas;

import principal.BancoDePalavras;

public class NivelMedio implements MecanicaDoJogo{

    private BancoDePalavras palavras = new BancoDePalavras();
	private int tentativas = 5;
    private int pontos = 0;
    
    @Override
    public String getNivel() {
        return "M�dio";
    }

    @Override
    public String getRegras() {
    	return "No Dicion�rio temos 20 Palavaras sobre o tema 'Java e Orieta��o a Objetos' \n"
        		+ "que ser�o embaralhadas de duas maneiras aleat�rias, \n"
        		+ "uma � trocando as posi��es das leatras e a outra, tente adivinhar. \n"
        		+ "Neste n�vel, voc� ter� limite de 5 Tentativas \n"
        		+ "e a cada palavra acertada, voc� ganhara 1 de pontos \n"
        		+ "no entanto, a cada palavra errada, voc� N�O perder� pontos. \n"
        		+ "ATEN��O: N�o utilize acentos, nem '�' e nem caracteres especias como '-' \n"
        		+ "Boa Sorte!!! \n";
    }

    @Override
    public String getPalavra() {
        return palavras.getNext();
    }

    @Override
    public String tentativa(String palavra, String resposta) {
        if(palavra.equals(resposta)){
            pontos++;
            return "Parab�ns, Voc� acertou e Ganhou 1 Ponto!!! Voc� ainda pode errar " + tentativas + " vezes.";
        }else{
            tentativas--;
            return "Aaahhh... Voc� Errou!!! Mas N�O Desanime. Tente Novamente, pois voc� ainda pode errar " + tentativas + " vezes.";
        }
    }

    @Override
    public String getResultadoFinal() {
        
    	if(pontos == 0) {
    		return "Infelizmente, n�o foi dessa vez... Sua pontua��o foi: " + pontos + " Ponto(s)!!!";
        }else {
        	return "Parab�ns!!! Sua pontua��o foi: " + pontos + " Ponto(s)!";
        }
    }
    
    @Override
    public boolean isOver() {
        if(tentativas <= 0){
            return true;
        }else {
            return false;
        }
    }
}
