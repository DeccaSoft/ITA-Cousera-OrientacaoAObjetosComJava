/*
 * @Author: Andr� Morais de Azevedo
 * @DateTime: 30/08/2020 17:28
 */
package embaralhador;

public interface Embaralhador {

	public String embaralhaPalavra(String palavra);
}
