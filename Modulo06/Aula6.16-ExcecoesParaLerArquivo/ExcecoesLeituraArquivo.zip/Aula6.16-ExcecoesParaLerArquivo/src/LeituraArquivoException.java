import java.io.IOException;

/*
 * @Author: Andr� Morais de Azevedo
 * @DateTime: 31/08/20 14:42
 */

public class LeituraArquivoException extends IOException {

	public LeituraArquivoException(String msg) {
		super(msg);
	}


}
