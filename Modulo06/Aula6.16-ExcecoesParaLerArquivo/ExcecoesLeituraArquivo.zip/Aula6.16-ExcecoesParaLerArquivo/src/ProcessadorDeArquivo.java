import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

/*
 * @Author: Andr� Morais de Azevedo
 * @DateTime: 31/08/20 14:20
 */

public class ProcessadorDeArquivo{

	public static HashMap<String, String> processar(String nomeArquivo) throws LeituraArquivoException, FileNotFoundException{
		//Retorna um map com as informa��es do arquivo lido
		//Formato: chave->valor
//Ex:		nome->Eduardo
//			sobrenome->Guerra
//			idade->35
		
		String linhaArquivo;
		String[] tokens;
		HashMap<String, String> informacoes = new HashMap<>();
		File file = new File(nomeArquivo);
		Scanner scanner = new Scanner(file);
		if (file.length() == 0) {
			throw new LeituraArquivoException("Aten��o: O Arquivo est� Vazio!!!");
		} else {
			try {
				//scanner = new Scanner(file);
				while (scanner.hasNextLine()) {
					linhaArquivo = scanner.nextLine();
					tokens = linhaArquivo.split("->");
					if (tokens.length < 2 || tokens.length > 2) {
					//if (!tokens.equals("->")) {
						throw new LeituraArquivoException("Aten��o: O Arquivo N�O tem um Formato V�lido!!!");
					} else {
						informacoes.put(tokens[0], tokens[1]);
					}
				}
			} catch (IOException exc) {
				throw new LeituraArquivoException("Aten��o: N�o Consegui Abrir o Arquivo!!!" + exc);
			}
		}
		scanner.close();
		return informacoes;
	}
}
